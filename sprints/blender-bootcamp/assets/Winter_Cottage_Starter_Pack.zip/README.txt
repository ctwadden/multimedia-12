WINTER COTTAGE — BLENDER 5.2.2
Extract this ZIP before opening or appending assets. Keep each model
beside its textures folder; do not move the blend files alone.
All supplied third-party assets are CC0. See CREDITS.json for their
creators and original source pages. The cottage and snowman are built
by you in the workbook, not supplied as completed models.
Use the NormalGL image when a Blender normal map is requested.
Fir: fir_sapling/fir_sapling_1k.blend > Object > fir_sapling_a.
Checksums in SHA256.json identify the original supplied files.
