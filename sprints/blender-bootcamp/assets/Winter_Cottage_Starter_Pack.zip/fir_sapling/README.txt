Fir Sapling — Poly Haven
Rico Cilliers (modeling), Rob Tuytel (photography)
https://polyhaven.com/a/fir_sapling
CC0: https://polyhaven.com/license
1K textures; original files, unmodified. Download/checksum record: credits.json
