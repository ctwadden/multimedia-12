# Night Shift practice assets

Human Skull by George Hodan, CC0 Public Domain. Source: https://www.publicdomainpictures.net/en/view-image.php?image=279751&picture=human-skull

This upper skull has no separate lower mandible. Use it for a local nose/socket/upper-bone reveal. Advanced jaw and wrinkle routes need suitable approved sources and are optional. Supply your own approved portrait and teacher-provided or appropriately licensed texture photographs. No creator portraits, video frames, music or class texture photos are redistributed.
