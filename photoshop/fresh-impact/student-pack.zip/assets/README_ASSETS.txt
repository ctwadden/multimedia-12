FRESH IMPACT — ASSET PROVENANCE

01_plain_can.png: original procedural studio teaching render made for this lesson, with simulated metal/condensation and a deliberately added blue inventory tape. Not a camera photograph. Can silhouette and light direction are authored to make the Pen/warp exercises reproducible.
02_lime_source.png: fruit detail cropped and re-isolated from AI-generated concept imagery produced in this conversation; placed on a neutral teaching backdrop. It is not a licensed stock photograph or documentary evidence.
03_splash_black.png: selected water-only details from AI-generated concept imagery, prepared into a monochrome light-element source on true black. No original generated brand or copy is present.
04_wrap_grid.png: original geometric calibration grid, for optional diagnosis only.
05_campaign_copy.txt: original fictional brief and copy.

No publisher photographs, font files or third-party stock assets are redistributed in this package. No student generative-AI account is needed for the supplied-asset workflow. Preserve the provenance notes when reusing these teaching assets.

Reference composites were built programmatically from the supplied sources. The cylinder projection is illustrative, not an exported Photoshop transform. The finished source-based reference—not any generated promotional image shown during preparation—is the tutorial target. No native completed Photoshop exemplar PSD is supplied.
